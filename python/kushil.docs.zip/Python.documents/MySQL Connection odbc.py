import pandas as pd
import pyodbc

cnxn = pyodbc.connect('DRIVER={Devart ODBC Driver for MySQL};'
                      'User ID=root;'
                      'Password=K#1122@aaaa;'
                      'Server=localhost;'
                      'Database=sys;'
                      'Port=3306;'
                      )

# Execute the SQL query
sql_query = "SELECT * FROM students"
df = pd.read_sql_query(sql_query, cnxn)
print(df)





#### update and commit



import mysql.connector

# Establish a connection to the MySQL server
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="K#1122@aaaa",
    database="sys"
)

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

# Define the UPDATE statement
sql = "UPDATE students SET name=%s,age = %s, email = %s WHERE id = %s"

# Specify the new values for the placeholders in the UPDATE statement
new_name='rahu'
new_age = 23
new_email = 'leela@gmail.com'
id_to_update = 10

# Execute the UPDATE statement with the new values
cursor.execute(sql, (new_name,new_age, new_email, id_to_update))

# Commit the changes to the database
conn.commit()

# Close the cursor and the connection
cursor.close()
conn.close()

