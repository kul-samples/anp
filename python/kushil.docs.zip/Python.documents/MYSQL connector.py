




## To connect and extract  mysql database with python and that extracted data converted into CSV files.

import pandas as pd
import mysql.connector
db=mysql.connector.connect(user='root',password='K#1122@aaaa',host='localhost',database='sys')

cursor=db.cursor()

query="select * from emp"

cursor.execute(query)
mydata=cursor.fetchall()


all_empno=[]
all_ename=[]
all_job=[]
all_mgr=[]
all_hiredate=[]
all_sal=[]
all_comm=[]
all_deptno=[]


for empno, ename, job, mgr, hiredate, sal, comm, deptno in mydata:
    all_empno.append(empno)
    all_ename.append(ename)
    all_job.append(job)
    all_mgr.append(mgr)
    all_hiredate.append(hiredate)
    all_sal.append(sal)
    all_comm.append(comm)
    all_deptno.append(deptno)


    dic={'empno':all_empno,'ename':all_ename,'job':all_job,'mgr':all_mgr,'hiredate':all_hiredate,'sal':all_sal,'comm':all_comm,'deptno':all_deptno}
    df=pd.DataFrame(dic)
    print(df)

    df.to_csv('C:/Users/SSS2022259/OneDrive/Desktop/lll/emptable.csv')



## To extracted two tables in mysql database and join that two tables and converted that data into csv files with python:



import pandas as pd
import mysql.connector

# Establishing the connection

conn = mysql.connector.connect(
   user='root', password='K#1122@aaaa', host='localhost', database='sys'
)

cursor = conn.cursor()  # Creating a cursor object using the cursor() method

sql = '''SELECT * FROM EMPLOYEE INNER JOIN CONTACT ON EMPLOYEE.CONTACT = CONTACT.ID''' # Retrieving the data from the query

cursor.execute(sql)  # Executing the query

result = cursor.fetchall()  # Fetching all rows from the query result
# print(result)

columns = [desc[0] for desc in cursor.description]  # Get column names from the cursor description
# print(columns)

df = pd.DataFrame(result, columns=columns)  # Create a DataFrame from the result with column names
print(df)

csv_file_path = 'C:/Users/SSS2022259/OneDrive/Desktop/lll/join.csv'  # Give path to csv file to save
df.to_csv(csv_file_path, index=False)  # Save DataFrame to CSV file with headers


conn.close() # Closing the connection








