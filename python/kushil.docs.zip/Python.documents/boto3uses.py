
         ### How many number of VPCs are in AWS

# import boto3
#
# # Create an EC2 client
# ec2_client = boto3.client('ec2', region_name='ap-south-1')
#
# # print(ec2_client)
#
# # Describe all VPCs
# response = ec2_client.describe_vpcs()
#
# # print(response)
# # #
# # # Get the count of VPCs
# vpc_count = len(response['Vpcs'])
# # print(vpc_count)#
# # # Display the count and VPC IDs in the terminal
# print(f"Number of VPCs in EC2: {vpc_count}")
# for vpc in response['Vpcs']:
#     print(f"VPC ID: {vpc['VpcId']}")


               ### VPC wise how many subnets with their details
#
# import boto3
#
# # Create an EC2 client
# ec2_client = boto3.client('ec2', region_name='ap-south-1')
#
# # Replace 'your_vpc_id' with the ID of the VPC you want to get subnet details for
# vpc_id = 'vpc-05d65aa79664e688f'
#
# # Describe subnets for the specified VPC
# response = ec2_client.describe_subnets(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
#
# # List to store subnet details (name and ID)
# subnets = []
#
# # Process each subnet in the response
# for subnet in response['Subnets']:
#     subnet_id = subnet['SubnetId']
#     subnet_name = ''
#     for tag in subnet.get('Tags', []):
#         if tag['Key'] == 'Name':
#             subnet_name = tag['Value']
#             break
#     subnets.append({'SubnetID': subnet_id, 'SubnetName': subnet_name})
#
# # Get the number of subnets
# subnet_count = len(subnets)
#
# # Print the number of subnets and their details
# print(f"Number of Subnets in EC2: {subnet_count}")
# for subnet in subnets:
#     print(f"Subnet ID: {subnet['SubnetID']}")
#     print(f"Subnet Name: {subnet['SubnetName']}")
#     print("-" * 30)

             ###  Upload local folder into s3 bucket
# import boto3
# import os
#
# def upload_folder_to_s3(bucket_name, local_folder_path, s3_folder_name=''):
#     # Create an S3 client
#     s3_client = boto3.client('s3', region_name='us-west-2')
#     if not s3_folder_name.endswith('/'):
#         s3_folder_name += '/'
#
#     for root, dirs, files in os.walk(local_folder_path):
#         for file in files:
#             local_file_path = os.path.join(root, file)
#             s3_key = s3_folder_name + os.path.relpath(local_file_path, local_folder_path).replace("\\", "/")
#             s3_client.upload_file(local_file_path, bucket_name, s3_key)
# #
# # # Replace these values with your own
# bucket_name = 'kushals3'
# local_folder_path = 'C:/Users/SSS2022259/OneDrive/Desktop/python/pythonn'
# s3_folder_name = 'python'  # Optional: leave empty if you want to upload to the root of the bucket
#
# upload_folder_to_s3(bucket_name, local_folder_path, s3_folder_name)



       ### Instance stop,start and terminated




# import boto3
#
# region_name = 'ap-south-1'
#
# # Initialize the EC2 client with the specified region
# ec2 = boto3.client('ec2', region_name=region_name)
#
# def stop_instance(instance_id):
#     try:
#         response = ec2.stop_instances(InstanceIds=[instance_id], DryRun=False)
#         print(f"Instance {instance_id} is stopping.")
#         return response
#     except Exception as e:
#         print(f"Error stopping instance: {e}")
#         return None
#
# def start_instance(instance_id):
#     try:
#         response = ec2.start_instances(InstanceIds=[instance_id], DryRun=False)
#         print(f"Instance {instance_id} is starting.")
#         return response
#     except Exception as e:
#         print(f"Error starting instance: {e}")
#         return None
#
#
#
# def terminate_instance(instance_id):
#     try:
#         response = ec2.terminate_instances(InstanceIds=[instance_id], DryRun=False)
#         print(f"Instance {instance_id} is terminating.")
#         return response
#     except Exception as e:
#         print(f"Error terminating instance: {e}")
#         return None
#
# # Replace 'instance_id' with the actual ID of the instance you want to manage
# instance_id = 'i-0263c6a37bcc39df1'

# Example usage:
# Stop the instance
# stop_response = stop_instance(instance_id)
# print(stop_response)

# Start the instance
# start_response = start_instance(instance_id)
# print(start_response)


# Terminate the instance
# terminate_response = terminate_instance(instance_id)
# print(terminate_response)


 ### how to attach a volume  to an ec2 server


# import boto3
# import time
#
#
# ec2_client = boto3.client('ec2', region_name='ap-south-1')  # Replace 'your_region' with your desired AWS region
#
# response = ec2_client.create_volume(
#     AvailabilityZone='ap-south-1b',  # Replace 'your_availability_zone' with the availability zone where you want to create the volume
#     Size=10,  # Replace with the desired size of the volume in GiB
#     VolumeType='gp2'  # Replace with the desired volume type (e.g., 'gp2' for General Purpose SSD)
# )
#
# volume_id = response['VolumeId']
# print(f"Volume created with ID: {volume_id}")
#
#
# waiter = ec2_client.get_waiter('volume_available')
# waiter.wait(VolumeIds=[volume_id])
#
# print("Volume is available and ready to be attached.")
#
# instance_id = 'i-0263c6a37bcc39df1'  # Replace 'your_instance_id' with the ID of your EC2 instance
#
# response = ec2_client.attach_volume(
#     Device='/dev/sdg',  # Replace with the desired device name on the instance (e.g., '/dev/sdf')
#     InstanceId=instance_id,
#     VolumeId=volume_id
# )
#
# print("Volume attached successfully.")




       ### Detach and delete a volume
#
# import boto3
#
# # Initialize EC2 client
# ec2_client = boto3.client('ec2', region_name='ap-south-1')  # Replace 'your_region' with your desired AWS region
#
# # Detach the volume from your EC2 instance
# volume_id = 'vol-00dd883c2cc7c6da7'  # Replace 'your_volume_id' with the ID of the volume you want to detach
# response = ec2_client.detach_volume(
#     VolumeId=volume_id
# )
#
# print("Volume detached successfully.")
#
#
#
# waiter = ec2_client.get_waiter('volume_available')
# waiter.wait(VolumeIds=[volume_id])
#
# print("Volume is available and ready to be deleted.")
#
# # Delete the volume
# response = ec2_client.delete_volume(
#     VolumeId=volume_id
# )
#
# print("Volume deleted successfully.")
#
#

